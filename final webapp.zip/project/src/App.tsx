import React, { useState } from 'react';
import { BrowserRouter as Router, Routes, Route, Link } from 'react-router-dom';
import { Play, Flame, Medal, Trophy, Shirt as TShirt, Soup, Menu, X } from 'lucide-react';
import WatchAdPage from './pages/WatchAdPage';
import LoginPage from './pages/LoginPage';
import SignupPage from './pages/SignupPage';

function HomePage() {
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  return (
    <div className="min-h-screen bg-gradient-to-b from-[#FF8C4B] via-[#E05188] to-[#2C1668] p-4">
        <div className="max-w-2xl mx-auto bg-[#2D2A54] rounded-3xl overflow-hidden">
          {/* Header */}
          <header className="p-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center text-white">
                <span className="text-2xl font-bold">Watch2Give</span>
              </div>
              
              {/* Mobile Menu Button */}
              <button
                className="md:hidden text-white p-2"
                onClick={() => setIsMenuOpen(!isMenuOpen)}
              >
                {isMenuOpen ? <X size={24} /> : <Menu size={24} />}
              </button>

              {/* Desktop Navigation */}
              <nav className="hidden md:flex gap-6 items-center text-white">
                <Link to="/watch-ad" className="hover:opacity-80">Watch Ad</Link>
                <Link to="/leaderboard" className="hover:opacity-80 flex items-center gap-1">
                  <Trophy size={18} />
                  Leaderboard
                </Link>
                <Link to="/badges" className="hover:opacity-80 flex items-center gap-1">
                  <Medal size={18} />
                  Badges
                </Link>
                <Link to="/login" className="hover:opacity-80">Login</Link>
                <Link to="/signup" className="hover:opacity-80">Sign Up</Link>
              </nav>
            </div>

            {/* Mobile Navigation */}
            {isMenuOpen && (
              <nav className="md:hidden mt-4 flex flex-col gap-4 text-white border-t border-white/10 pt-4">
                <Link 
                  to="/watch-ad" 
                  className="hover:opacity-80 flex items-center gap-2"
                  onClick={() => setIsMenuOpen(false)}
                >
                  <Play size={18} />
                  Watch Ad
                </Link>
                <Link 
                  to="/leaderboard" 
                  className="hover:opacity-80 flex items-center gap-2"
                  onClick={() => setIsMenuOpen(false)}
                >
                  <Trophy size={18} />
                  Leaderboard
                </Link>
                <Link 
                  to="/badges" 
                  className="hover:opacity-80 flex items-center gap-2"
                  onClick={() => setIsMenuOpen(false)}
                >
                  <Medal size={18} />
                  Badges
                </Link>
                <Link 
                  to="/login" 
                  className="hover:opacity-80"
                  onClick={() => setIsMenuOpen(false)}
                >
                  Login
                </Link>
                <Link 
                  to="/signup" 
                  className="hover:opacity-80"
                  onClick={() => setIsMenuOpen(false)}
                >
                  Sign Up
                </Link>
              </nav>
            )}
          </header>

          {/* Main Content */}
          <main
            className="min-h-screen p-6"
            style={{
              background: `linear-gradient(
                180deg,
                #FFAC4B 0%,    /* Orange Peel */
                #FE7F53 25%,   /* Coral */
                #FE6C5F 40%,   /* Bittersweet */
                #C6589F 70%,   /* Mulberry */
                #B856AD 100%   /* Steel Pink */
              )`,
            }}
          >
            <h1 className="text-3xl sm:text-4xl font-bold text-white mb-6">
              Watch & Earn AdTokens
            </h1>

            {/* Video Player */}
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              <div className="lg:col-span-2">
                <div className="bg-[#2D2A54] rounded-xl aspect-video flex items-center justify-center mb-4">
                  <Play className="w-16 h-16 text-[#8B5CF6] cursor-pointer hover:text-[#9061FF] transition-colors" />
                </div>
                <Link 
                  to="/watch-ad" 
                  className="block w-full bg-[#2D2A54] text-white py-3 rounded-xl hover:bg-opacity-90 transition-colors text-center"
                >
                  Watch Now
                </Link>
              </div>

              {/* Progress Section */}
              <div className="space-y-4">
                <div className="bg-[#2D2A54] p-4 rounded-xl text-white">
                  <h2 className="text-xl mb-2">Ad Progress</h2>
                  <div className="flex items-center gap-2">
                    <div className="flex-1 h-2 bg-gray-700 rounded-full overflow-hidden">
                      <div className="w-1/4 h-full bg-[#4FD1C5]"></div>
                    </div>
                    <span className="text-[#4FD1C5]">5/20 Ads</span>
                  </div>
                </div>

                {/* Leaderboard */}
                <div className="bg-[#2D2A54] p-4 rounded-xl text-white">
                  <h2 className="text-xl mb-4">Top 5 Leaderboard</h2>
                  <div className="space-y-2">
                    {[
                      { name: 'Alice', points: 240 },
                      { name: 'Bob', points: 200 },
                      { name: 'Charlie', points: 180 },
                      { name: 'Aliss', points: 140 },
                      { name: 'Fmil.i', points: 55 },
                    ].map((user, index) => (
                      <div key={user.name} className="flex items-center justify-between">
                        <div className="flex items-center gap-2">
                          <span>{index + 1}</span>
                          <span>{user.name}</span>
                        </div>
                        <span>{user.points}</span>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </div>

            {/* Stats Section */}
            <div className="bg-[#2D2A54] mt-6 p-4 rounded-xl text-white flex justify-between">
              <div className="flex items-center gap-2">
                <Flame className="text-orange-500" />
                <span>Streak: 3-Day</span>
                <div className="flex">
                  {[1, 2, 3, 4].map((_, i) => (
                    <Flame key={i} size={20} className="text-orange-500" />
                  ))}
                </div>
              </div>
              <div className="flex items-center gap-2">
                <Medal />
                <span>Badges: 2 unlocked</span>
              </div>
            </div>

            {/* Proof of Giving */}
            <div className="mt-6">
              <h2 className="text-2xl font-bold text-white mb-4">Proof-of-Giving</h2>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="bg-[#4FD1C5] p-4 rounded-xl">
                  <img
                    src="https://images.unsplash.com/photo-1620799140408-edc6dcb6d633?auto=format&fit=crop&w=800"
                    alt="Donated T-Shirts"
                    className="w-full h-48 object-cover rounded-lg mb-4"
                  />
                  <div className="flex items-center gap-2 text-white">
                    <TShirt />
                    <span className="font-semibold">Donated T-Shirts</span>
                  </div>
                  <p className="text-white mt-1">Vendor 1</p>
                </div>
                <div className="bg-[#4FD1C5] p-4 rounded-xl">
                  <img
                    src="https://images.unsplash.com/photo-1498837167922-ddd27525d352?auto=format&fit=crop&w=800"
                    alt="Soup Kitchen"
                    className="w-full h-48 object-cover rounded-lg mb-4"
                  />
                  <div className="flex items-center gap-2 text-white">
                    <Soup />
                    <span className="font-semibold">Soup Kitchen</span>
                  </div>
                  <p className="text-white mt-1">Vendor 2</p>
                </div>
              </div>
            </div>
          </main>
        </div>
      </div>
    
  );
}

function App() {
  return (
    <Router>
      <Routes>
        <Route path="/" element={<HomePage />} />
        <Route path="/watch-ad" element={<WatchAdPage />} />
        <Route path="/login" element={<LoginPage />} />
        <Route path="/signup" element={<SignupPage />} />
      </Routes>
    </Router>
  );
}

export default App;