import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { Play, ArrowLeft, Gift, Clock, Coins } from 'lucide-react';

interface VideoAd {
  id: string;
  title: string;
  duration: number;
  reward: number;
  thumbnail: string;
  category: string;
}

const availableAds: VideoAd[] = [
  {
    id: '1',
    title: 'Eco-Friendly Products',
    duration: 30,
    reward: 5,
    thumbnail: 'https://images.unsplash.com/photo-1542601906990-b4d3fb778b09?auto=format&fit=crop&w=800',
    category: 'Sustainability'
  },
  {
    id: '2',
    title: 'Healthy Living Tips',
    duration: 45,
    reward: 8,
    thumbnail: 'https://images.unsplash.com/photo-1498837167922-ddd27525d352?auto=format&fit=crop&w=800',
    category: 'Health'
  },
  {
    id: '3',
    title: 'Tech Innovation',
    duration: 60,
    reward: 10,
    thumbnail: 'https://images.unsplash.com/photo-1518770660439-4636190af475?auto=format&fit=crop&w=800',
    category: 'Technology'
  },
  {
    id: '4',
    title: 'Educational Content',
    duration: 40,
    reward: 7,
    thumbnail: 'https://images.unsplash.com/photo-1503676260728-1c00da094a0b?auto=format&fit=crop&w=800',
    category: 'Education'
  }
];

function WatchAdPage() {
  const [selectedAd, setSelectedAd] = useState<VideoAd | null>(null);
  const [timeLeft, setTimeLeft] = useState(0);
  const [isWatching, setIsWatching] = useState(false);
  const [isCompleted, setIsCompleted] = useState(false);

  useEffect(() => {
    let timer: number;
    if (isWatching && timeLeft > 0) {
      timer = window.setInterval(() => {
        setTimeLeft((prev) => prev - 1);
      }, 1000);
    } else if (timeLeft === 0 && isWatching) {
      setIsCompleted(true);
      setIsWatching(false);
    }
    return () => clearInterval(timer);
  }, [isWatching, timeLeft]);

  const startWatching = () => {
    if (selectedAd) {
      setTimeLeft(selectedAd.duration);
      setIsWatching(true);
    }
  };

  const selectAd = (ad: VideoAd) => {
    setSelectedAd(ad);
    setIsCompleted(false);
    setIsWatching(false);
    setTimeLeft(ad.duration);
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-[#FF8C4B] via-[#E05188] to-[#2C1668] p-4">
      <div className="max-w-4xl mx-auto bg-[#2D2A54] rounded-3xl overflow-hidden">
        <header className="p-4 flex items-center gap-4">
          <Link to="/" className="text-white hover:opacity-80 flex items-center gap-2">
            <ArrowLeft size={24} />
            <span>Back to Home</span>
          </Link>
        </header>

       <main
  className="min-h-screen p-6"
  style={{
    background: `linear-gradient(
      180deg,
      #FFAC4B 0%,    /* Orange Peel */
      #FE7F53 25%,   /* Coral */
      #FE6C5F 40%,   /* Bittersweet */
      #C6589F 70%,   /* Mulberry */
      #B856AD 100%   /* Steel Pink */
    )`,
  }}
>
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            {/* Video Player Section */}
            <div className="lg:col-span-2 bg-[#2D2A54] rounded-xl p-6">
              <h1 className="text-3xl font-bold text-white mb-6">
                {selectedAd ? selectedAd.title : 'Select an Advertisement'}
              </h1>
              
              <div className="aspect-video bg-black rounded-xl flex items-center justify-center mb-6">
                {!selectedAd && (
                  <div className="text-white text-xl text-center">
                    <Play className="w-20 h-20 mx-auto mb-4 text-[#8B5CF6]" />
                    <p>Select a video from the list to start watching</p>
                  </div>
                )}
                {selectedAd && !isWatching && !isCompleted && (
                  <Play 
                    className="w-20 h-20 text-[#8B5CF6] cursor-pointer hover:text-[#9061FF] transition-colors"
                    onClick={startWatching}
                  />
                )}
                {isWatching && (
                  <div className="text-white text-2xl">
                    Time remaining: {timeLeft}s
                  </div>
                )}
                {isCompleted && (
                  <div className="flex flex-col items-center gap-4">
                    <Gift className="w-20 h-20 text-[#4FD1C5]" />
                    <span className="text-white text-xl">Ad Completed! {selectedAd?.reward} Tokens Earned!</span>
                  </div>
                )}
              </div>

              {selectedAd && (
                <div className="flex justify-between items-center text-white">
                  <div className="flex items-center gap-2">
                    <Coins className="text-[#4FD1C5]" />
                    <span>Reward: {selectedAd.reward} AdTokens</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Clock className="text-[#4FD1C5]" />
                    <span>Duration: {selectedAd.duration} seconds</span>
                  </div>
                </div>
              )}

              {selectedAd && !isWatching && !isCompleted && (
                <button
                  onClick={startWatching}
                  className="mt-6 w-full bg-[#4FD1C5] text-white py-3 rounded-xl hover:bg-opacity-90 transition-colors"
                >
                  Start Watching
                </button>
              )}
              {isCompleted && (
                <Link
                  to="/"
                  className="mt-6 block w-full bg-[#4FD1C5] text-white py-3 rounded-xl hover:bg-opacity-90 transition-colors text-center"
                >
                  Return to Home
                </Link>
              )}
            </div>

            {/* Available Videos Section */}
            <div className="bg-[#2D2A54] rounded-xl p-6">
              <h2 className="text-xl font-bold text-white mb-4">Available Videos</h2>
              <div className="space-y-4">
                {availableAds.map((ad) => (
                  <div
                    key={ad.id}
                    onClick={() => selectAd(ad)}
                    className={`cursor-pointer rounded-lg overflow-hidden transition-transform hover:scale-[1.02] ${
                      selectedAd?.id === ad.id ? 'ring-2 ring-[#4FD1C5]' : ''
                    }`}
                  >
                    <img
                      src={ad.thumbnail}
                      alt={ad.title}
                      className="w-full h-32 object-cover"
                    />
                    <div className="p-3 bg-[#1F1D40]">
                      <h3 className="text-white font-semibold mb-1">{ad.title}</h3>
                      <div className="flex justify-between text-sm text-gray-300">
                        <span className="flex items-center gap-1">
                          <Clock size={14} />
                          {ad.duration}s
                        </span>
                        <span className="flex items-center gap-1">
                          <Coins size={14} />
                          {ad.reward}
                        </span>
                      </div>
                      <div className="mt-1">
                        <span className="text-xs text-[#4FD1C5]">{ad.category}</span>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </main>
      </div>
    </div>
  );
}

export default WatchAdPage;