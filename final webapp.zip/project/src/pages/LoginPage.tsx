import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { Mail, Lock, ArrowLeft } from 'lucide-react';

function LoginPage() {
  const [formData, setFormData] = useState({
    email: '',
    password: '',
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // Handle login logic here
  };

  return (
   <div className="min-h-screen bg-gradient-to-b from-[#FF8C4B] via-[#E05188] to-[#2C1668] p-4">
     <div className="max-w-2xl mx-auto bg-[#2D2A54] rounded-3xl overflow-hidden">
      <div 
        className="min-h-screen"
        style={{
          background: `linear-gradient(
            180deg,
            #FFAC4B 0%,    /* Orange Peel */
            #FE7F53 25%,   /* Coral */
            #FE6C5F 40%,   /* Bittersweet */
            #C6589F 70%,   /* Mulberry */
            #B856AD 100%   /* Steel Pink */
          )`,
        }}
      >
        <div className="max-w-md mx-auto pt-16 pb-8 px-4">
          <Link to="/" className="text-white hover:opacity-80 flex items-center gap-2 mb-8">
            <ArrowLeft size={24} />
            <span>Back to Home</span>
          </Link>

          <div className="bg-[#2D2A54] rounded-3xl p-8">
            <h1 className="text-3xl font-bold text-white mb-8 text-center">Welcome Back</h1>
            
            <form onSubmit={handleSubmit} className="space-y-6">
              <div>
                <label className="block text-white text-sm font-medium mb-2">Email</label>
                <div className="relative">
                  <Mail className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" size={20} />
                  <input
                    type="email"
                    className="w-full bg-[#1F1D40] text-white pl-10 pr-4 py-3 rounded-xl focus:outline-none focus:ring-2 focus:ring-[#4FD1C5]"
                    placeholder="Enter your email"
                    value={formData.email}
                    onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                  />
                </div>
              </div>

              <div>
                <label className="block text-white text-sm font-medium mb-2">Password</label>
                <div className="relative">
                  <Lock className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" size={20} />
                  <input
                    type="password"
                    className="w-full bg-[#1F1D40] text-white pl-10 pr-4 py-3 rounded-xl focus:outline-none focus:ring-2 focus:ring-[#4FD1C5]"
                    placeholder="Enter your password"
                    value={formData.password}
                    onChange={(e) => setFormData({ ...formData, password: e.target.value })}
                  />
                </div>
              </div>

              <button
                type="submit"
                className="w-full bg-[#4FD1C5] text-white py-3 rounded-xl hover:bg-opacity-90 transition-colors font-medium"
              >
                Log In
              </button>
            </form>

            <p className="text-white text-center mt-6">
              Don't have an account?{' '}
              <Link to="/signup" className="text-[#4FD1C5] hover:underline">
                Sign Up
              </Link>
            </p>
          </div>
        </div>
      </div>
    </div>
 </div>
  );
}

export default LoginPage;